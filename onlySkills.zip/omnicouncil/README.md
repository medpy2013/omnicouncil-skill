<!-- Copyright 2026 Mohamed Aouaci. SPDX-License-Identifier: Apache-2.0 -->

# OmniCouncil

**An explicitly invoked critique, verification, and delivery workflow for AI assistants.** OmniCouncil routes a task to the relevant domain guidance, challenges a first proposal, revises it, and then completes the authorized request when tools permit.

[![Apache-2.0](https://img.shields.io/badge/License-Apache--2.0-blue.svg)](LICENSE)
[![Manual evaluation plan](https://img.shields.io/badge/Behavior-manual%20evaluation-orange)](EVALUATION.md)

> OmniCouncil can improve the process an assistant is asked to follow. It cannot make a model infallible, independently intelligent, or incapable of fabrication.

## How it works

![Animated illustration of the OmniCouncil critique, revision, and delivery sequence](assets/omnicouncil-flow.gif)

The animated sequence is illustrative. See [the full process diagram](assets/omnicouncil-process.svg) and its plain-language explanation in [Arabic](README.ar.md).

| Stage | What the skill asks the assistant to do |
| --- | --- |
| Specialist | Identify the relevant principle, evidence, and important unknowns first. |
| Engineer | Make a concrete first proposal. |
| Devil’s Advocate | Test the strongest plausible failure mode without inventing a flaw. |
| Skeptical End User | Check effort, clarity, accessibility, and likely misunderstanding. |
| Revision | Resolve valid criticism, narrow unsupported claims, and identify unresolved risk. |
| Maestro | Deliver the revised answer or perform the authorized work, then accurately report verification. |

The familiar “AI as an employee who agrees with the boss” comparison is a **metaphor** for over-agreement and unsupported confidence. Models do not literally feel fear or intend to lie. OmniCouncil adds a factuality checkpoint: identify material claims, verify important ones against available evidence, check sources and calculations, look for counterevidence, and label what remains uncertain. These instructions can reduce avoidable errors; they cannot stop hallucinations or promise a percentage improvement.

The named roles are simulated perspectives unless the host actually starts separate agents. A concise visible review is shown when the requested format allows it; hidden chain-of-thought is not exposed. The council critique must not replace implementation, research, or another concrete task the user requested.

## Invoke it only when you want it

OmniCouncil is **not intended to run for every conversation**. Use the host’s explicit command, or say “Use OmniCouncil for this request.”

| Host | Explicit-use guidance | Important limitation |
| --- | --- | --- |
| OpenAI Codex | Install the skill folder and invoke `$omnicouncil`. `agents/openai.yaml` sets `allow_implicit_invocation: false`. | Explicit-only selection is configured for Codex; still verify the installed version appears in the skill list. |
| Claude Code | Install in `.claude/skills/omnicouncil/`, add Claude Code's `disable-model-invocation: true` field to the frontmatter (instructions below), and invoke `/omnicouncil`. | The one-line host setting is applied during setup; the portable core file stays within the standard skill manifest. |
| Gemini CLI | Install using its skills command, then inspect with `/skills list`. | Its skill system can activate skills when relevant; this package cannot guarantee “manual invocation only” there. If that matters, attach the files only to requests where you explicitly want them, or disable the installed skill when idle. |
| ChatGPT app | For a one-off, attach/paste `SKILL.md` and say “Use OmniCouncil.” For a reusable custom GPT, put the core procedure in its Instructions and upload relevant references as Knowledge files. | This is not a universal import of a Codex skill. Follow the current product UI and check explicit invocation behavior yourself. |
| OpenAI API / other agent frameworks | Use the host’s skill, prompt, or tool configuration. The OpenAI Responses API supports uploading a skill ZIP and attaching a skill reference to a supported shell tool. | API setup requires application code and credentials. Each host may interpret metadata and linked files differently. |

No one package can install itself in every model or AI app. Skills belong to a **host product or agent runtime**, not to a model in isolation. See [INSTALLATION.md](INSTALLATION.md) for current platform steps and fallback instructions. Compatibility here means “the files can be adapted,” not “behavior has been tested on every model.”

## Package contents

- `SKILL.md` — explicit invocation, role workflow, evidence/candor rules, task completion, routing, and output limits.
- `agents/openai.yaml` — Codex metadata and explicit-only policy.
- `references/` — selective guidance for software, AI/ML, games/3D, product ideas, research, writing, and general problem-solving.
- `examples/` — concise output examples, including when no material flaw is found.
- `assets/` — static process diagram and animated overview.
- `INSTALLATION.md` — platform-specific installation guidance and limitations.
- `README.ar.md` — Arabic overview and usage guide.
- `EVALUATION.md` — observable manual checks and release criteria.
- `HALLUCINATION-EVALUATION.md` — a paired evaluation protocol for measuring factual-error changes without inventing a percentage.
- `INSTRUCTION-GUIDE.md` — what instructions are intended to influence, and their limits.
- `LICENSE` — Apache License 2.0.

Reference files are **not** separately installed subskills. The main skill selects relevant references; only hosts that can access the package files can use them.

## Download

- [Download `onlySkills.zip`](https://github.com/medpy2013/omnicouncil-skill/raw/refs/heads/main/onlySkills.zip) — full package, with one top-level `omnicouncil/` folder.
- [Browse the source files](.) — inspect the instructions before installation.

## Evaluation and release honesty

The included test plan is a manual protocol, not a report of tests already passed. Run it on each platform/model/version you plan to support and publish the actual date and results. A structural check can catch broken frontmatter or missing files; it cannot prove model behavior. Never advertise “100% reliable,” “works everywhere,” or “cannot lie.”

## License and attribution

Licensed under Apache-2.0. Copyright 2026 Mohamed Aouaci. See [LICENSE](LICENSE). The license permits reuse under its terms; it does not certify performance or grant rights to third-party material included by downstream users.


