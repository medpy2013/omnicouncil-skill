<!-- Copyright 2026 Mohamed Aouaci. SPDX-License-Identifier: Apache-2.0 -->

# Changelog

User-visible changes to OmniCouncil are recorded here. Dates use ISO 8601.

## 1.3.0 — 2026-10-26

- Strengthen factuality checks by separating important draft claims into neutral verification questions and checking sources without treating the draft or simulated agreement as evidence.
- Document a paired evaluation protocol for measuring factual-error changes. No hallucination-reduction percentage is claimed until a specific host, model, language, and test set are measured.
- Improve the English and Arabic guides with clearer source-checking language and navigation between translations.

## 1.2.0

- Add explicit-only invocation guidance for supported hosts and clearer host compatibility limits.
- Add manual behavior and hallucination-evaluation plans, bilingual installation guidance, and visual workflow assets.
- Clarify that council roles are simulated perspectives unless separate agents are actually used.
\n