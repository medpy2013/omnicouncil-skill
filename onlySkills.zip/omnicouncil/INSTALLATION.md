<!-- Copyright 2026 Mohamed Aouaci. SPDX-License-Identifier: Apache-2.0 -->

# Installation and invocation

**Last reviewed: 2026-10-26.** Product interfaces and skill support change. Check the linked official documentation before relying on a command that may have changed.

## First: what is being installed?

An AI model does not install a skill by itself. The **host application or agent runtime** must support reusable skills, files, instructions, or tools. This package is portable Markdown, but its references and frontmatter only work when the host can read them. When the host lacks a skill system, attach or paste the core `SKILL.md` and explicitly request OmniCouncil for that task.

The ZIP contains a single top-level `omnicouncil/` folder. Extract it intact; do not upload only the ZIP as a text/knowledge file when the host expects an actual skill directory.

## OpenAI Codex

1. Download [`onlySkills.zip`](https://github.com/medpy2013/omnicouncil-skill/raw/refs/heads/main/onlySkills.zip) and extract it.
2. Copy the extracted `omnicouncil` folder into your Codex skills directory:
   - User scope: `~/.codex/skills/omnicouncil/`
   - On Windows this is usually `%USERPROFILE%\.codex\skills\omnicouncil\`.
3. Keep `SKILL.md`, `agents/`, `references/`, and the other folders together.
4. Restart Codex or refresh skill discovery if required by your version.
5. Invoke it with `$omnicouncil` or clearly ask to use OmniCouncil. `agents/openai.yaml` disables implicit invocation.
6. Confirm the skill is visible and run the relevant cases from `EVALUATION.md`.

Official docs: [OpenAI Codex skills](https://developers.openai.com/codex/skills).

## Claude Code

1. Clone the repository into your user skill directory, or extract the ZIP and move its `omnicouncil` folder there:

   ```powershell
   git clone https://github.com/medpy2013/omnicouncil-skill.git "$HOME\.claude\skills\omnicouncil"
   ```

   For a project-only installation, use `<project>/.claude/skills/omnicouncil/` instead.
2. Start or reload Claude Code if needed.
3. Type `/omnicouncil` at the start of your request.

To keep this skill manual-only in Claude Code, add the following Claude-specific field inside the YAML frontmatter at the top of `SKILL.md` (below `description`, before the closing `---`):

```yaml
disable-model-invocation: true
```

Claude Code documents this field as preventing the model from invoking that skill on its own while preserving manual slash invocation. It is intentionally not in the portable core frontmatter because generic skill validators may reject host-specific keys. This setting does not configure Claude.ai, Claude API deployments, or other Anthropic integrations automatically.

Official docs: [Claude Code skills](https://code.claude.com/docs/en/skills).

## Gemini CLI

Gemini CLI supports Agent Skills. From its interactive session use:

```text
/skills list
```

To install from this repository, follow the current Gemini CLI command and its confirmation prompts:

```powershell
gemini skills install https://github.com/medpy2013/omnicouncil-skill
```

Then use `/skills list` to verify discovery and `/skills reload` after updates. Gemini CLI's documented skill system may activate an enabled skill when it judges it relevant and asks for consent. This package's `disable-model-invocation` field is not a cross-platform guarantee. For strict “only when I call it” use, attach `SKILL.md` (and at most one relevant reference) to the request instead of leaving the skill enabled, or disable it while not in use.

Official docs: [Using Agent Skills](https://github.com/google-gemini/gemini-cli/blob/main/docs/cli/using-agent-skills.md) and [Getting started](https://github.com/google-gemini/gemini-cli/blob/main/docs/cli/tutorials/skills-getting-started.md).

## ChatGPT app

### One task at a time

Attach `SKILL.md` to the conversation (and only the relevant file from `references/`, if needed), then write: **“Use OmniCouncil for this request.”** This is the simplest portable method; the files will not persist automatically into other conversations.

### Custom GPT

If your account has GPT creation enabled, put the core workflow from `SKILL.md` in the GPT's **Instructions**, and upload reference files individually under **Knowledge**. Then test the explicit invocation behavior in Preview and keep the GPT private until satisfied. Knowledge uploads are not identical to a filesystem skill: relative links and automatic reference routing may not work as written. Do not assume that uploading the ZIP alone installs a skill.

Official docs: [Creating and editing GPTs](https://help.openai.com/en/articles/8554397-creating-and-editing-gpts).

## OpenAI API and agent frameworks

For supported OpenAI API workflows, the [Skills API guide](https://developers.openai.com/api/docs/guides/tools-skills) documents uploading a directory or a ZIP with one top-level folder, then referencing the uploaded version from a supported hosted shell tool. This is an application integration: it is not an end-user toggle in ChatGPT, and it requires API credentials plus code that attaches the skill to the right tool call.

For Claude API, cloud-hosted agent products, Cursor, Windsurf, VS Code extensions, or another host, use that product's current official instructions. If it does not support Agent Skills natively, use the manual attach/paste method. Do not assume host-specific frontmatter, slash commands, or linked references will carry over.

## Troubleshooting

- **Skill is missing:** confirm the folder contains `SKILL.md` at the expected depth and refresh/restart discovery.
- **Only the first file seems available:** the host may not read linked files. Attach the single relevant reference manually.
- **It activates without being asked:** turn it off in the host's skill manager. If the host has no explicit-only control, do not keep it installed and enabled; attach it only to intended requests.
- **It still gives a wrong answer:** instructions are probabilistic. Check the sources, verify the work, report the failure, and add that scenario to the evaluation plan.

## References

- [OpenAI Codex skills](https://developers.openai.com/codex/skills)
- [OpenAI API Skills](https://developers.openai.com/api/docs/guides/tools-skills)
- [Claude Code skills](https://code.claude.com/docs/en/skills)
- [Gemini CLI skill management](https://github.com/google-gemini/gemini-cli/blob/main/docs/cli/using-agent-skills.md)
